# The 10-Minute Pre-Launch Security Checklist

For anyone who built an app with Lovable, Bolt, Cursor, Claude Code, Replit, v0 or any AI tool.

Each check takes about a minute. For each one, you get **what to look for** and a **prompt to paste into your coding agent** so it checks for you.
If a check fails, fix it before you share your link anywhere.

---

### 1. No secret keys in your website code

Secret keys (OpenAI `sk-...`, Stripe `sk_live_...`, Supabase `service_role`) must never be in files that load in the browser.
**Think of it like this:** your website is a shop window. Anything in it, anyone can read.

> Search this project for API keys or secrets written directly in code, including OpenAI, Anthropic, Stripe secret keys, Supabase service_role keys, AWS keys and database URLs with passwords. List every file and line. Do not change anything yet.

**Safe to be public:** Stripe `pk_` keys, the Supabase **anon** key, the Firebase `apiKey`.

### 2. Your .env file is not in your repo

> Check whether any .env file with real values is committed to this repo, and whether .gitignore contains .env*. Report what you find.

### 3. Nothing secret uses a public prefix

Variables starting with `NEXT_PUBLIC_`, `VITE_`, `REACT_APP_` or `EXPO_PUBLIC_` are copied into your website.

> List every environment variable with a NEXT_PUBLIC_, VITE_, REACT_APP_ or EXPO_PUBLIC_ prefix. Flag any whose name or value looks secret.

### 4. Supabase: Row Level Security is ON for every table

Open Supabase, then the Table Editor. If any table says **RLS disabled**, anyone can read it with your public key.

> List every Supabase table and whether Row Level Security is enabled. For each policy, show its USING clause.

### 5. Supabase: no policy says `USING (true)`

That rule means "let everyone in." It's the pattern behind a 2025 vulnerability that exposed data in 170+ apps.

> Find any Supabase policy using USING (true) or WITH CHECK (true) on a table that holds user data. Suggest an ownership-based replacement using auth.uid().

### 6. Firebase: rules aren't wide open

If your rules say `allow read, write: if true` or are still in "test mode," your database is public.

### 7. Users can't see each other's stuff

Log in as yourself, open something that belongs to you (an order, a note, a profile), and change the number or ID in the URL. If you can see someone else's, that's a serious bug.

> For every API route that takes an ID, check that it verifies the record belongs to the logged-in user. List any route that doesn't.

### 8. Payments: the webhook checks it's really Stripe

> Check the Stripe webhook handler. Does it verify the signature with stripe.webhooks.constructEvent on the raw body? Is the price set on the server, not taken from the browser? Does access come only from the verified webhook, not the success page?

### 9. Your AI endpoints can't be spammed

If your app calls a paid AI API, one bot looping your endpoint can cost you thousands overnight.

> Check whether endpoints that call paid AI APIs require login and have rate limiting. Report any that don't.

**Also do this today:** set a spending cap or budget alert in every AI and cloud account you use.

### 10. Debug mode is off

> Check for debug: true, DEBUG=True, verbose error pages, or test/debug routes that would be live in production.

---

## Found something scary?

Fix it, and **rotate any key that was ever exposed**. Deleting it from the code isn't enough, because bots copy keys within minutes.

## Want someone to check it for you?

The **Ship-Ready Check** runs all of this (and more) on your repo and sends a plain-English report within 24 hours.

- **Quick Scan, $29:** a prioritized list of what's wrong and how to fix it.
- **Full, $79:** the same, plus copy-paste fix prompts for your coding agent and a free re-scan.

https://shipreadycheck-dev.github.io

*This checklist lowers your risk. It can't guarantee your app is secure.*
