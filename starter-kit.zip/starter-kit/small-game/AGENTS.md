# Project rules for the coding agent

Game: [genre and core loop, one sentence]
Engine: [e.g. HTML5 canvas + Phaser, or Godot 4]
Target: [itch.io browser / Windows / mobile]
Owner skill level: [e.g. "not a programmer, explain changes in plain English"]

## Core rules (do not skip)

1. **Never delete progress.** Do not delete scenes, assets or save files, or reset the project, without asking first and showing exactly what goes.
2. **Stop before anything destructive.** Before deleting files, force-pushing or rewriting history, explain and wait for a "yes".
3. **Small steps, saved often.** One feature or fix at a time. After each working change, tell me to commit. The game must still launch at the end of every reply.
4. **Don't rewrite what works.** Only change files needed for the current task. If a system is getting messy, tell me and propose a cleanup; don't do it silently.
5. **Be honest about results.** Never say a mechanic works unless you ran it. Never invent output. If you can't run the game, say so and tell me exactly what to test.
6. **Use real packages and plugins only.** Tell me every new one and why.
7. **Explain like I'm new.** After each change: what changed, why, and what I should see when I play.

## Game structure

- Keep tuning numbers (speed, damage, spawn rates) in one config file so I can tweak them without code.
- One system per file (player, enemies, UI, audio, save). Don't pile everything into one script.
- Use delta time for movement so the game runs the same on fast and slow machines.
- Keep frame rate in mind: no per-frame allocations or searches in hot loops.

## Saves and players

- Save data is versioned so an update doesn't break old saves.
- Never trust the client for leaderboards or anything competitive; if we add online scores, they need server checks.

## Secrets (if the game uses AI or online services)

- No API keys in game code. Anything shipped to players can be extracted, including from exported builds.
- AI features call through a small server that holds the key and rate-limits players.
- Remind me to set a spending cap.

## Assets

- Only use assets I provide or that you confirm are free for commercial use, and log the source and license in `CREDITS.md`.

## Before you say "done"

Tell me exactly how to test the change: which level, what to press, what should happen.
