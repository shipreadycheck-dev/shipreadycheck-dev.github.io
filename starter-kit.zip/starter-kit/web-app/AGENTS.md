# Project rules for the coding agent

Project: [what this app does, one sentence]
Stack: [e.g. Next.js, Supabase, Stripe, OpenAI]
Owner skill level: [e.g. "not a programmer, explain changes in plain English"]

## Core rules (do not skip)

1. **Never touch production data.** Do not run migrations, deletes, resets or seed scripts against the production database. If a task needs that, stop and ask, and show the exact command.
2. **Stop before anything destructive.** Before deleting files, dropping tables, force-pushing or rewriting history, explain what will happen and wait for a "yes".
3. **Small steps, saved often.** Make one change at a time. After each working change, tell me to commit (or commit with a clear message if I've allowed it). Never leave the project in a broken state at the end of a reply.
4. **Don't rewrite what works.** Only change files needed for the current task. If you want to refactor something else, ask first.
5. **Be honest about results.** Never say something works unless you ran it and saw it work. Never invent test results, data or output. If a test fails, say so. If you're unsure, say "I haven't verified this."
6. **Use real packages only.** Only add dependencies you're certain exist and are widely used. Tell me every new package you add and why.
7. **Explain like I'm new.** After each change: what changed, why, and how I can check it myself.

## Secrets and keys

- Never write an API key, password or token into code. Use environment variables.
- Secret keys are only read in server code (API routes, server actions, edge functions). Never in components or anything under a client-side folder.
- Never give a secret a public prefix (`NEXT_PUBLIC_`, `VITE_`, `REACT_APP_`).
- Safe in the browser: Supabase anon key, Stripe `pk_` key. Never in the browser: Supabase `service_role`, Stripe `sk_`, any AI provider key.
- Keep `.env*` in `.gitignore`. Maintain a `.env.example` with names only, no values.
- If you ever see a real key in the code or chat, stop and tell me to rotate it.

## Database (Supabase)

- Every new table gets `ENABLE ROW LEVEL SECURITY` in the same migration.
- Every policy checks ownership (`auth.uid() = user_id`). Never use `USING (true)` on user data.
- Never edit old migrations. Create new ones.

## Auth and access

- Every API route that reads or changes user data must check the user is logged in AND owns the record.
- Admin and paid features are checked on the server, not just hidden in the UI.

## Payments (Stripe)

- Prices are set on the server. Never trust an amount from the browser.
- Webhooks verify the signature with `stripe.webhooks.constructEvent` on the raw body.
- Grant access only from the verified webhook, never from the success page.

## AI API calls

- Only from the server, only for logged-in users, always with a per-user rate limit.
- Remind me to set a spending cap with the provider.

## Before you say "done"

Run the build. Check for type errors. Re-read the rules above against what you changed.
