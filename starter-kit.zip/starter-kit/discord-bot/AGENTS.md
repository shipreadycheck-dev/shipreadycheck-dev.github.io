# Project rules for the coding agent

Project: [what this bot does, one sentence]
Stack: [discord.js or discord.py, hosting e.g. Railway/Fly/home PC]
Owner skill level: [e.g. "not a programmer, explain changes in plain English"]

## Core rules (do not skip)

1. **Never touch production data.** Do not wipe, reset or migrate the live database or data files. If a task needs that, stop and ask, and show the exact command.
2. **Stop before anything destructive.** Before deleting files, dropping tables, force-pushing or rewriting history, explain what will happen and wait for a "yes".
3. **Small steps, saved often.** One change at a time. After each working change, tell me to commit. Never leave the bot unable to start at the end of a reply.
4. **Don't rewrite what works.** Only change files needed for the current task. Ask before refactoring.
5. **Be honest about results.** Never say something works unless you ran it. Never invent output. If unsure, say "I haven't verified this."
6. **Use real packages only.** Only well-known, existing dependencies. Tell me every new one and why.
7. **Explain like I'm new.** After each change: what changed, why, and how I can check it.

## Bot token and secrets

- The bot token lives only in an environment variable (`DISCORD_TOKEN`). Never in code, never in a config file that's committed, never printed to logs or chat.
- Keep `.env*` in `.gitignore`. Maintain `.env.example` with names only.
- If the token ever appears in code, chat or a public repo, stop and tell me to reset it in the Discord Developer Portal immediately. Discord scans GitHub, but bots that steal tokens are faster.

## Permissions

- Request the minimum intents and permissions the bot needs. Never ask for Administrator.
- Commands that ban, kick, delete messages or change roles must check the user has that permission in the server first.
- Owner-only commands check the user ID against an allowlist from an environment variable.

## Abuse and cost

- Add a per-user cooldown to every command, especially any that call a paid AI API.
- Never let the bot @everyone or @here, or mass-DM users.
- Ignore messages from other bots to avoid loops.
- If the bot calls a paid AI API, remind me to set a spending cap.

## Reliability

- Catch errors in every command handler so one bad command can't crash the bot.
- Log errors without logging message content or user data unless I ask.

## Before you say "done"

Start the bot, run the changed command once, and report exactly what happened.
