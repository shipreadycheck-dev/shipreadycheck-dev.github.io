# Vibe Coder Starter Kit

Rules files that keep your coding agent from breaking things, leaking keys, or touching what it shouldn't.

**How to use:** pick your project type, copy the `AGENTS.md` into the root of your project, and rename it to whatever your tool reads:

| Tool | File name |
|---|---|
| Claude Code | `CLAUDE.md` |
| Cursor | `.cursor/rules/project.mdc` (or `.cursorrules`) |
| Codex, Windsurf, most others | `AGENTS.md` |

Then fill in the `[brackets]` at the top. That's it.

| Folder | For |
|---|---|
| `web-app/` | Next.js / React apps with Supabase, Stripe, or AI APIs |
| `discord-bot/` | Discord bots (discord.js or discord.py) |
| `small-game/` | Browser or Godot games |

All three share the same core rules (safety, git, honesty). The bottom half of each is specific to the project type.

Pair it with the **10-Minute Pre-Launch Security Checklist** before you ship.
